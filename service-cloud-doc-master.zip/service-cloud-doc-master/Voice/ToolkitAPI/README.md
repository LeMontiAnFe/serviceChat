# Service Cloud Voice Toolkit API

Service Cloud Voice examples have moved to [this repository](https://github.com/service-cloud-voice/examples-from-doc).
