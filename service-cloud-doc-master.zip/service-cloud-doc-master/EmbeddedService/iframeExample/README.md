# Use an Iframe to Protect Embedded Service Chat on Your Website

This example goes along with the blog post, [Use an Iframe to Protect Embedded Service Chat on Your Website](https://developer.salesforce.com/blogs/2020/02/use-an-iframe-to-protect-embedded-service-chat-on-your-website.html).

* [homepage_parent.html](homepage_parent.html)
* [childpage_chat.html](childpage_chat.html)
