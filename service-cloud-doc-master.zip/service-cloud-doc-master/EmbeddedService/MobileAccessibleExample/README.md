# Mobile Accessible Embedded Chat Example Code

This example goes along with the blog post, [Turn Down the Screen Noise with Mobile Web Chat](https://developer.salesforce.com/blogs/2020/03/turn-down-the-screen-noise-with-mobile-web-chat.html).

* [mobile_accessible.html](mobile_accessible.html)
