# Embedded Service Examples

These examples demonstrate use cases for [Embedded Service for Web](https://help.salesforce.com/articleView?id=live_agent_intro.htm&type=5).
